file(REMOVE_RECURSE
  "CMakeFiles/crypto_ta_client.dir/crypto_ta_client.c.o"
  "crypto_ta_client"
  "crypto_ta_client.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/crypto_ta_client.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
