# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "C"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_C
  "/home/wx/WorkStation/ItemCode/62443-4-2/exec/app/tee/crypto_ta_client.c" "/home/wx/WorkStation/ItemCode/62443-4-2/exec/app/tee/build-deploy/CMakeFiles/crypto_ta_client.dir/crypto_ta_client.c.o"
  )
set(CMAKE_C_COMPILER_ID "GNU")

# The include file search paths:
set(CMAKE_C_TARGET_INCLUDE_PATH
  "/home/wx/WorkStation/ItemCode/62443-4-2/logger/.deps/optee-arm64/include"
  "../../../../optee_ta_examples/ta/crypto_ta/include"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
